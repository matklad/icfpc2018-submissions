echo "$@"
ARGS="$@" ./gradlew :run
